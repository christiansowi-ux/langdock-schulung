# Mein Merkzettel für Tag 2

Meine vier Felder heißen:

Das stand nach dem ersten Test in der Ausgabe:

Das hat sich beim zweiten Test geändert:

Mein echter Verbrauch vorher / nachher:

Hier brauche ich noch Hilfe:
