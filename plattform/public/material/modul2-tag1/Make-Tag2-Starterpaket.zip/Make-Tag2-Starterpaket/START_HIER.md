# Tag 2: Aus vier Angaben wird ein Text

Dienstag, 27.10.2026. Lies die vollständige Anleitung im Tagesheft.

1. Eigenes neues Szenario M2-02 Redaktionsbriefing anlegen. Zeitplan aus lassen.
2. JSON > Parse JSON hinzufügen. Den Inhalt von Redaktionsbriefing.json in JSON string einfügen. Das sind Übungsdaten, kein Make-Blueprint zum Importieren.
3. Zunächst nur dieses Modul mit Run once ausführen. Vier Felder in der Ausgabe prüfen.
4. Tools > Compose a string anschließen. Projekt:, Thema:, Kanal:, Status: tippen und jeweils das passende Feld aus Parse JSON auswählen. Letzte feste Zeile: Noch keine Veröffentlichung.
5. Beide Bausteine mit Run once ausführen. Alle vier Werte im Ergebnis vergleichen.
6. Nur JSON string durch Zweiter-Versuch.json ersetzen. Erneut starten; der zweite Baustein bleibt unverändert. Erwartet: Nordlicht, Interview vorbereiten, Internes Projektbriefing und ENTWURF.

Es wird nichts verschickt. Keine weiteren Konten verbinden. Rechenbeispiel: 1 + 2 + 2 = 5 Credits, weitere Tests zusätzlich. Echte Anzeige im Make-Konto vorher und nachher prüfen.
