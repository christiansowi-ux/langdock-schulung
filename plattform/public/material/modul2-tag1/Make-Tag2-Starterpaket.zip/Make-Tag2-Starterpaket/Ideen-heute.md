# Freiwillige Ideen für Tag 2

Die Hauptaufgabe ist der Datenzettel mit zwei Beispielen. Die Ideen sind keine acht weiteren Pflichtaufgaben.

9 · Korrekturwünsche fürs Videoteam sammeln
Ein Zettel könnte zeigen: „Runde 2 - Datum im Bildtext ändern“. So sieht die nächste Person genau, worum es geht.
Heute anpassbar: Den Text in thema ändern und das neue Ergebnis prüfen. Make schneidet dadurch noch kein Video.

10 · Eine Videovorschau zur Prüfung vormerken
Ein interner Zettel erinnert daran, Bild, Text, Ton und Format anzusehen. Ein Link allein prüft die Datei noch nicht.
Freigaben und Bedingungen kommen erst Mittwoch. Heute genügt ein Textentwurf ohne Versand.

11 · Eine Druckanfrage übersichtlich notieren
Beispiel: „200 Flyer; Papier noch offen“. Die offene Frage soll im Zettel sichtbar bleiben.
Heute anpassbar: thema auf diesen Text und kanal auf Vertrieb setzen. Es entsteht kein verbindliches Angebot.

12 · Ein vorbereitetes Angebot intern vorlegen
Ein Hinweis könnte anzeigen, dass ein Mensch ein Angebot prüfen soll. Er soll keine ungeprüfte Zusage auslösen.
Das Filtern nach einer Freigabe folgt Mittwoch. Heute keinen Außenversand oder echten Preis einbauen.

13 · Ein Kundengespräch vorbereiten
Aus „Format und Abholung klären“ wird ein kleiner Gesprächszettel. Bestätigte Fakten und offene Fragen bleiben erkennbar.
Heute anpassbar: thema auf den Beispieltext und kanal auf Gespräch setzen. Anschließend die Ausgabe vergleichen.

14 · Eine Rückfrage als Entwurf festhalten
Beispiel: „Nach Papiermuster fragen“. So kann das Team den nächsten Schritt besprechen.
Heute nur einen Zettel erstellen. Ein späterer Terminlauf und eine echte Kontaktaufnahme wären zusätzliche Schritte.

15 · Offene und erledigte Vorgänge unterscheiden
Ein Status kann helfen, nicht versehentlich an einem abgeschlossenen Fall weiterzuarbeiten.
Heute darfst du den Text im Feld status ändern und die Ausgabe ansehen. Ein Status stoppt noch keinen Ablauf; dafür braucht man später eine Bedingung.

16 · Neue Kolleginnen und Kollegen begrüßen
Eine persönliche Begrüßung lässt sich aus einem Namen und festen Textteilen zusammensetzen. Das kennst du schon von Tag 1.
Wenn du das gestern gebaut hast: Luna und Mira vergleichen. Keine echten Nutzerkonten anlegen und nichts automatisch verschicken.