# Mittwoch ganz leicht: Freigabe-Ampel

28.10.2026. Nur die Hauptaufgabe bauen, danach höchstens ein Extra wählen. Keine Make-Blueprints in diesem Paket.

1. Neues Szenario M2-03 Freigabe-Ampel. Planung aus. Tools > Set variable: Variable name status, Variable value FERTIG. Einmal allein testen.
2. Tools > Compose a string ergänzen: Beitrag zur Planung bereit. Status: plus den ausgewählten status-Wert aus Baustein 1.
3. Auf die Verbindung klicken. Filter: status, Textvergleich Equal to, fester Wert FERTIG. Speichern.
4. Ganzen Ablauf testen: FERTIG erzeugt die Meldung. Nur im ersten Baustein zu ENTWURF ändern, speichern, neu starten: jetzt soll der Weg stoppen.

Geplant 1 + 2 + 1 = ungefähr 4 Credits. Echten Verbrauch im Konto prüfen. Die Meldung steht nur in Make. Es wird nichts verschickt.

Freiwillige Extras und ihre vollständigen Klickwege stehen im Lernheft: Schlagzeile aus RSS lesen oder Idee in eigener Google-Tabelle sichern. Google-Extra nur mit vorhandenem eigenen Konto.
