# Mein Ampel-Test

Bei FERTIG passierte:

Bei ENTWURF passierte:

Mein echter Verbrauch vorher / nachher:

Meine Frage:
