# Nur zum Nachlesen

17 · Ein erster Tag ohne Sucherei
Eine kurze Liste hilft neuen Kolleginnen beim Einstieg.
Ein Einfall kann im Ideenparkplatz landen. Kein HR-System nötig.

18 · Ein Mentoring-Vorschlag
Zwei Menschen sollen erst nach Zustimmung miteinander sprechen.
Die Ampel erklärt das Prinzip. Ein Teststatus ersetzt keine echte Zustimmung.

19 · Ein kleines Teamritual
Eine Idee für einen kurzen Freitagsaustausch sammeln.
Im Ideenparkplatz speichern. Das erstellt noch keinen Kalendereintrag.

20 · Eine klare Übergabe
Eine Vertretung soll sehen: Flyertext fertig, Bildauswahl offen.
Für diese Lernrunde genügt eine verständliche Notiz. Kein kompliziertes Projektwerkzeug anschließen.

21 · Eine Rückfrage festhalten
Bei einer Anfrage fehlt der Termin.
Die Rückfrage als Idee oder Notiz sammeln. Make soll keinen Termin erfinden.

22 · Einen Supportfall weitergeben
Ein Problem soll die richtige Person zur Prüfung bekommen.
Die Ampel hilft beim Verstehen der Weitergabe. Einen echten Versand bauen wir hier nicht.

23 · Eine Beschwerde zur Prüfung legen
Eine Rückmeldung zur Druckfarbe muss ein Mensch ansehen.
Eine interne Prüfnotiz vorbereiten. Keine automatische Zusage an Kunden erzeugen.