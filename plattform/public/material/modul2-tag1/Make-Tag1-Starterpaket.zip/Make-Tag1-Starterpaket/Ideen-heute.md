# Die Ideen sind freiwilliger Ausblick

Heute reicht die Begrüßung mit zwei Namen. Kein JSON lernen und keine zusätzlichen Konten verbinden.

1 · Ideen an einem Ort sammeln
Stell dir einen Zettel vor: „Blick hinter die Kulissen - für Instagram“. Später kann Make solche Angaben immer gleich ordnen.
Heute nur verstehen: Ein Thema wird in einen festen Text eingesetzt, ähnlich wie unser Name. Mehrere Felder kommen Dienstag.

2 · Einen Newsletter vorbereiten
Aus Thema, Datum und Zielgruppe entsteht ein kurzer Zettel für die Person, die den Newsletter schreibt. Das ist noch kein versandter Newsletter.
Beispiel: „Ideenatelier am 06.11.“ Der Termin soll unverändert übernommen werden. Dafür kommen Dienstag weitere Felder dazu.

3 · Erkennen, welche Kampagne freigegeben ist
Ein interner Hinweis könnte lauten: „Die Herbstaktion ist freigegeben.“ Ohne Freigabe soll kein solcher Hinweis entstehen.
Das ist eine Vorschau auf Mittwoch: Ein Filter entscheidet, ob ein Schritt ausgeführt werden darf. Heute noch nicht nachbauen.

4 · Einen Kampagnenlink verständlich beschriften
Statt eines nackten Links bekommst du einen Zettel mit Kampagnenname und Zieladresse. Das Team sieht leichter, wozu der Link gehört.
Das folgt derselben Idee wie die Begrüßung: feste Wörter mit ausgewählten Angaben verbinden. Ein Linktext misst noch keine Klicks.

5 · Eine alte Idee später wieder anschauen
Eine Fotoidee soll nicht verloren gehen. Make könnte einen Zettel für die spätere Prüfung vorbereiten.
Beispiel: „Workshop-Foto erneut prüfen“. Einen automatischen Erinnerungstermin bauen wir heute noch nicht.

6 · Ein Videoprojekt übersichtlich vorbereiten
Projektname, Thema und geplanter Einsatz werden zu einem kurzen Zettel für das Team. So müssen dieselben Angaben nicht mehrfach abgetippt werden.
Beispiel: „Nordlicht - Interview vorbereiten“. Mehrere Angaben übernehmen wir ab Dienstag. Es wird dabei noch kein Video erstellt.

7 · Nur freigegebene Videoanfragen weitergeben
Eine Anfrage soll erst in die Planung gehen, wenn ein Mensch sie freigegeben hat. Make kann später prüfen, ob die vereinbarte Freigabe vorliegt.
Das üben wir Mittwoch mit erfundenen Angaben. Ein Testwert ersetzt keine echte Einwilligung oder geschäftliche Freigabe.

8 · Einheitliche Namen für Projektdateien vorbereiten
Aus Projekt und Arbeitsschritt könnte der Vorschlag „Nordlicht_Interview_Entwurf“ entstehen. Das Team erkennt leichter, was gemeint ist.
Heute entsteht nur ein Textvorschlag. Für das tatsächliche Umbenennen echter Dateien wäre später eine zusätzliche Verbindung nötig.