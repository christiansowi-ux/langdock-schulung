# Dein erster Ablauf in Make

Heute nur eine Aufgabe: aus einem Namen eine Begrüßung machen.

1. Lies die einfache Anleitung im Tagesheft.
2. Baustein 1: Tools > Set variable. Variable name: vorname. Variable value: Luna.
3. Ersten Baustein einmal mit Run once testen. Die Ausgabe soll Luna enthalten.
4. Baustein 2: Tools > Compose a string. Hallo und ein Leerzeichen tippen, den Namenswert aus Baustein 1 auswählen, dann ! Willkommen in Modul 2. tippen.
5. Speichern und beide Bausteine mit Run once starten. Ausgabe: Hallo Luna! Willkommen in Modul 2.
6. Nur im ersten Baustein Luna zu Mira ändern. Speichern, nochmals starten. Ausgabe: Hallo Mira! Willkommen in Modul 2.

Automatische Planung aus lassen. Es wird nichts verschickt. Keine zusätzlichen Konten verbinden. Rechenbeispiel für diese Versuche: 1 + 2 + 2 = 5 Credits. Echte Kontoanzeige vorher und nachher prüfen.

Das sind Merkzettel, keine importierbaren Make-Abläufe. Die Ideen sind freiwilliger Ausblick. Du musst sie heute nicht nachbauen.
