# Mein kleiner Merkzettel

Das habe ich im ersten Baustein eingetragen:

Das kam im zweiten Baustein heraus:

Das passierte nach dem Wechsel von Luna zu Mira:

Mein Verbrauch laut Konto vorher / nachher:

Hier brauche ich noch Hilfe:
