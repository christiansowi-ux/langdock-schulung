24 · FAQ-Ergänzungen als Entwurf sammeln
Workflow 2: Thema „Welche Dateiformate werden angenommen?“, Kanal „FAQ-Entwurf“. Antwort bleibt noch offen.
Ausbau: Später freigegebene Wissensquelle; keine Website automatisch ändern.

25 · Erledigte Rückfragen dokumentieren
Workflow 2: „Papierauswahl bestätigt“, Kanal „Abschlussnotiz“.
Ausbau: Später Service- oder CRM-Anbindung; tatsächlichen Abschluss nur mit Beleg markieren.

26 · Besprechungsergebnisse weitergeben
Workflow 2: „Mira prüft Text; Bild noch offen“, Kanal „Protokoll“.
Ausbau: Später erlaubte Notizquelle; KI darf Vorschläge nicht zu Beschlüssen machen.

27 · Freigaben vor Änderungen verlangen
Workflow 3 entsprechend umstellen und false testen.
Ausbau: Später Projekttracker; tatsächliche Dateiänderung bleibt ein eigener Schritt.

28 · Fehlende Projektangaben sichtbar halten
Workflow 2: Thema „Druckidee; Termin noch offen“, Kanal „Projektprüfung“.
Ausbau: Später Pflichtfeldprüfung; leere Felder nicht mit geratenen Angaben füllen.

29 · Termine eindeutig in Übergaben schreiben
Workflow 2 zunächst mit „26.10.2026 10:00 Europe/Berlin“ als bestätigtem Text; Datumskapitel nachlesen.
Ausbau: Später formatDate und ein Kalender; Textübergabe ist noch kein Kalendereintrag.

30 · Ein kleines Testprotokoll erzeugen
Workflow 2: Thema „Luna zu Mira geändert; Ergebnis geprüft“, Kanal „Testprotokoll“.
Ausbau: Keine weitere App nötig; erst ein selbst ausgeführter Test erlaubt diese Ergebnisbehauptung.