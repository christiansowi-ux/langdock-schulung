# Modul 2 · Lektion 1 · Tag 4/4

Donnerstag, 29.10.2026: Test-API, Zeitangaben und ein nachvollziehbarer eigener Ablauf.
Nur Testmaterial, keine Make-Blueprints. Automatische Planung aus lassen; Creditverbrauch vor/nach Versuch prüfen. Andere Etappen folgen an ihrem Tag.
